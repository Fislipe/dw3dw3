USUARIOS = [
    {"id": 1, "nome": "joao", "email":"joaozinhogamer@gmail.com"},
    {"id": 2, "nome": "carlos", "email":"carlos00@gmail.com"},
    {"id": 3, "nome": "ellen", "email":"ellen@gmail.com"},
    {"id": 4, "nome": "vitor", "email":"vitorzin@gmail.com"},
    {"id": 5, "nome": "veloso", "email":"velosogameplays@gmail.com"}
    ]   